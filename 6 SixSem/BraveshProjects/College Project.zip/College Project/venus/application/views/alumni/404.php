<br>
<br>
<br>
<br>
<div align="center">
	<h1>404</h1>
	<h3><?php echo $this->lang->line('404_message'); ?></h3>
</div>
