<!-- ================== BEGIN BASE JS ================== -->
<script src="<?php echo base_url(); ?>assets/admin/plugins/jquery/jquery-3.2.1.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/jquery/jquery-migrate-1.1.0.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/jquery-ui/jquery-ui.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/bootstrap/4.0.0/js/bootstrap.bundle.min.js"></script>
<!--[if lt IE 9]>
<script src="<?php echo base_url(); ?>assets/admin/crossbrowserjs/html5shiv.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/crossbrowserjs/respond.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/crossbrowserjs/excanvas.min.js"></script>
<![endif]-->
<script src="<?php echo base_url(); ?>assets/admin/plugins/slimscroll/jquery.slimscroll.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/js-cookie/js.cookie.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/js/theme/material.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/js/apps.min.js"></script>
<!-- ================== END BASE JS ================== -->

<!-- ================== BEGIN PAGE LEVEL JS ================== -->
<script src="<?php echo base_url(); ?>assets/admin/plugins/gritter/js/jquery.gritter.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/flot/jquery.flot.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/flot/jquery.flot.time.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/flot/jquery.flot.resize.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/flot/jquery.flot.pie.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/sparkline/jquery.sparkline.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/jquery-jvectormap/jquery-jvectormap.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/jquery-jvectormap/jquery-jvectormap-world-mill-en.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/js/demo/dashboard.min.js"></script>

<script src="<?php echo base_url(); ?>assets/admin/plugins/gritter/js/jquery.gritter.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/bootstrap-sweetalert/sweetalert.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/js/demo/ui-modal-notification.demo.min.js"></script>

<script src="<?php echo base_url(); ?>assets/admin/plugins/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/ionRangeSlider/js/ion-rangeSlider/ion.rangeSlider.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/bootstrap-colorpicker/js/bootstrap-colorpicker.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/masked-input/masked-input.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/bootstrap-timepicker/js/bootstrap-timepicker.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/password-indicator/js/password-indicator.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/bootstrap-combobox/js/bootstrap-combobox.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/bootstrap-select/bootstrap-select.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/bootstrap-tagsinput/bootstrap-tagsinput.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/bootstrap-tagsinput/bootstrap-tagsinput-typeahead.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/jquery-tag-it/js/tag-it.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/bootstrap-daterangepicker/moment.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/bootstrap-daterangepicker/daterangepicker.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/select2/dist/js/select2.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/bootstrap-eonasdan-datetimepicker/build/js/bootstrap-datetimepicker.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/bootstrap-show-password/bootstrap-show-password.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/bootstrap-colorpalette/js/bootstrap-colorpalette.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/jquery-simplecolorpicker/jquery.simplecolorpicker.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/clipboard/clipboard.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/js/demo/form-plugins.demo.min.js"></script>

<script src="<?php echo base_url(); ?>assets/admin/plugins/parsley/dist/parsley.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/highlight/highlight.common.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/js/demo/render.highlight.js"></script>

<script src="<?php echo base_url(); ?>assets/admin/plugins/jquery-file-upload/js/vendor/jquery.ui.widget.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/jquery-file-upload/js/vendor/tmpl.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/jquery-file-upload/js/vendor/load-image.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/jquery-file-upload/js/vendor/canvas-to-blob.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/jquery-file-upload/blueimp-gallery/jquery.blueimp-gallery.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/jquery-file-upload/js/jquery.iframe-transport.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/jquery-file-upload/js/jquery.fileupload.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/jquery-file-upload/js/jquery.fileupload-process.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/jquery-file-upload/js/jquery.fileupload-image.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/jquery-file-upload/js/jquery.fileupload-audio.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/jquery-file-upload/js/jquery.fileupload-video.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/jquery-file-upload/js/jquery.fileupload-validate.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/jquery-file-upload/js/jquery.fileupload-ui.js"></script>
<!--[if (gte IE 8)&(lt IE 10)]>
    <script src="<?php echo base_url(); ?>assets/admin/plugins/jquery-file-upload/js/cors/jquery.xdr-transport.js"></script>
<![endif]-->
<script src="<?php echo base_url(); ?>assets/admin/js/demo/form-multiple-upload.demo.min.js"></script>

<script src="<?php echo base_url(); ?>assets/admin/plugins/DataTables/media/js/jquery.dataTables.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/DataTables/media/js/dataTables.bootstrap.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/DataTables/extensions/Buttons/js/dataTables.buttons.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/DataTables/extensions/Buttons/js/buttons.bootstrap.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/DataTables/extensions/Buttons/js/buttons.flash.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/DataTables/extensions/Buttons/js/jszip.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/DataTables/extensions/Buttons/js/pdfmake.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/DataTables/extensions/Buttons/js/vfs_fonts.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/DataTables/extensions/Buttons/js/buttons.html5.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/DataTables/extensions/Buttons/js/buttons.print.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/DataTables/extensions/Responsive/js/dataTables.responsive.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/js/demo/table-manage-buttons.demo.min.js"></script>

<script src="<?php echo base_url(); ?>assets/admin/plugins/ckeditor/ckeditor.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/bootstrap-wysihtml5/dist/bootstrap3-wysihtml5.all.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/js/demo/form-wysiwyg.demo.min.js"></script>
<!-- ================== END PAGE LEVEL JS ================== -->

<script>
	$(document).ready(function() {
		App.init();
		Notification.init();
		FormPlugins.init();
		Highlight.init();
		FormMultipleUpload.init();
		TableManageButtons.init();
		FormWysihtml5.init();

		window.setTimeout(function() {
			$(".alert").slideUp(500, function(){
				$(this).remove();
			});
		}, 5000);
	});
</script>
